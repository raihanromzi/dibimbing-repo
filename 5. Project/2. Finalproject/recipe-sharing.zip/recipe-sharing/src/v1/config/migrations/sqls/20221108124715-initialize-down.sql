/* Replace with your SQL commands */
DROP DATABASE recipe_db;
