# Update Side Effect Status
UPDATE Village.Vaccination
SET SideEffect = true
WHERE PersonID = 1