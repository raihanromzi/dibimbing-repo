CREATE DATABASE Village;

USE Village;